const express = require('express');
const router = express.Router();
const {
  markAttendance,
  getAttendanceByClass,
  initAttendanceByClass,
 getAttendanceDatesByClass,
 getAbsentDatesByStudent,
 restoreAttendance
} = require('../controllers/attendanceController'); 

// Ghi điểm danh cho 1 sinh viên
router.post('/', markAttendance);

// Lấy ds ngày điểm danh
router.get('/dates/:classId', getAttendanceDatesByClass);

// Khôi phục buổi vắng
router.put('/restore', restoreAttendance);

// Lấy danh sách điểm danh theo lớp và ngày
router.get('/:classId', getAttendanceByClass);

// Khởi tạo điểm danh cho cả lớp hôm nay
router.post('/init/:classId', initAttendanceByClass);

// Lấy danh sách ngày vắng
router.get('/absent-dates/:classId/:studentId', getAbsentDatesByStudent);


module.exports = router;
